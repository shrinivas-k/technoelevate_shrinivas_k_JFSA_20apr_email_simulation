package com.te.emailSimulation.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.te.emailSimulation.Userbean.user.User;

//import com.te.mailsimulation.beans.EmailInfoBean;
//import com.te.mailsimulation.exceptions.EmailException;

@Repository
public class EmailDAOHibernateImpl implements Emaildao {

	@PersistenceUnit
	private EntityManagerFactory factory;

	@Override
	public user getEmailData(String email) {

		EntityManager manager = factory.createEntityManager();
		User user = manager.find(User.class, email);
		if (user != null) {
			user.setPassword(null);
		}
		manager.close();
		return user;
	}

	@Override
	public boolean deleteEmailData(String email) {
		boolean isDeleted = false;

		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			User user = manager.find(User.class, email);
			manager.remove(user);
			transaction.commit();
			isDeleted = true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			throw new EmailException("Data asssociated with email " + email+ "  not Found");
		}

		return isDeleted;
	}

	@Override
	public boolean addEmailData(User user) {
		boolean isInserted = false;
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		try {
			transaction.begin();
			manager.persist(user);
			transaction.commit();
			isInserted = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return isInserted;
	}

	@Override
	public boolean updateRecord(User emailInfoBean) {
		boolean isUpdated = false;

		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		try {
			transaction.begin();
			User actualInfo = manager.find(User.class, emailInfoBean.getEmail());

			if (User.getEmail() != null &&User.getEmail() != "") {
				actualInfo.setEmail(User.getEmail());
			}

			if (User.getName() != "") {
				actualInfo.setName(User.getName());
			}

			if (User.getPassword() != null && User.getPassword() != "") {
				actualInfo.setPassword(User.getPassword());
			}

			transaction.commit();
			isUpdated = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}

		return isUpdated;
	}

	@Override
	public List<User> getAllEmail() {

		EntityManager manager = factory.createEntityManager();
		Query query = manager.createQuery("from EmployeeInfoBean");
		ArrayList<User> emailInfoBeans = new ArrayList<User>();
		try {
			user = (ArrayList<User>) query.getResultList();
			for (User user : user) {
				user.setPassword(null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			emailInfoBeans = null;

		}

		return emailInfoBeans;
	}
	