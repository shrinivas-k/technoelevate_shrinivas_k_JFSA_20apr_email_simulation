package com.te.emailSimulation;

public class app {

}
