package com.te.emailSimulation.Userbean.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;
@Entity
@Table(name="user_info")
@Data
public class User implements Serializable {
public User(String name2, String password2) {
		// TODO Auto-generated constructor stub
	}
public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Column
private String name;
	@Column
private String password;
}
