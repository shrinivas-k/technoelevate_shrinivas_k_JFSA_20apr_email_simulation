package com.te.emailSimulation.controller;

import javax.mail.internet.MimeMessage;

import org.springframework.core.io.InputStreamSource;

public class MimeMessageHelper {

	public MimeMessageHelper(MimeMessage mimeMessage, boolean b, String string) {
		// TODO Auto-generated constructor stub
	}

	public void setTo(String emailToRecipient) {
		// TODO Auto-generated method stub
		
	}

	public void setFrom(String emailfromrecipient) {
		// TODO Auto-generated method stub
		
	}

	public void setText(String emailMessage) {
		// TODO Auto-generated method stub
		
	}

	public void setSubject(String emailSubject) {
		// TODO Auto-generated method stub
		
	}

	public void addAttachment(String originalFilename, InputStreamSource inputStreamSource) {
		// TODO Auto-generated method stub
		
	}

}
