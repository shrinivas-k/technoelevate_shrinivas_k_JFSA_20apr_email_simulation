package com.te.emailSimulation.dao;

import java.util.List;

import com.te.emailSimulation.Userbean.user.User;
//import com.te.mailsimulation.beans.EmailInfoBean;

public interface Emaildao {

	public User getEmailData(String email);
	
	public boolean deleteEmailData(String email);
	
	public boolean addEmailData(User user);
	
	public boolean updateRecord(User user);
	
	public List<User> getAllEmail();
}
